from flask import Flask

def valid_time(time):
    return time > 0

app = Flask(__name__)

@app.route('/')
def hello_world():
    return 'Hello, world'

if __name__ == '__main__':
    app.run(debug=True, port=6999)