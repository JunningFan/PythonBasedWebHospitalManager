from server import app, valid_time
from flask import request, render_template, redirect, url_for
from Calculator import Calculator


@app.route('/interest_total', methods=['POST', 'GET'])
def interest_total():
    if request.method == 'POST':
        result = request.form
        print(result)
        for i in result.values():
            if not i or float(i) < 0:   #detecting empty input
                return 'invalid input'
        calc = Calculator(float(result['amountInvested']), float(result['interestRate']))
        return render_template('interest_form.html', calc_total=True, total = calc.total_interest(float(result['timeInvestment'])))
    return render_template('interest_form.html', calc_total=True)

@app.route('/interest_time', methods=['POST', 'GET'])
def interest_time():
    if request.method == 'POST':
        result = request.form
        print(result)
        for i in result.values():
            if not i or float(i) < 0:   #detecting empty input
                return 'invalid input'
        calc = Calculator(float(result['amountInvested']), float(result['interestRate']))
        return render_template('interest_form.html', calc_time=True, time = calc.time_required(float(result['total'])))
    return render_template('interest_form.html', calc_time=True)


@app.route('/time', methods=['POST', 'GET'])
def time_interest():
    pass


@app.route('/credits', methods=['GET'])
def credits():
    return render_template('credits.html', name = 'Junning Fan')

@app.route('/', methods=['POST', 'GET'])
def default():
    return redirect(url_for('interest_total'))